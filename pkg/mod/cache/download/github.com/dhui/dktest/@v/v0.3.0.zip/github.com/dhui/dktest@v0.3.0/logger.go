package dktest

type logger interface {
	Log(...interface{})
}
