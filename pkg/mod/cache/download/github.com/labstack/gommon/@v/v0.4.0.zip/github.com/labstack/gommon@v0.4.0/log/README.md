## WORK IN PROGRESS

### Usage

[log_test.go](log_test.go)
