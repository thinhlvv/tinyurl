CREATE TABLE movies (
  user_id   INT,
  name      STRING(40),
  director  STRING(40)
);
