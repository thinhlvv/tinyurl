CREATE TABLE books (
  user_id integer,
  name    varchar(40),
  author  varchar(40)
);
