DROP INDEX UsersEmailIndex
