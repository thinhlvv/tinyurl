DROP TABLE Transactions
