// +build godoc_vfs

package cli

import (
	_ "github.com/golang-migrate/migrate/v4/source/godoc_vfs"
)
